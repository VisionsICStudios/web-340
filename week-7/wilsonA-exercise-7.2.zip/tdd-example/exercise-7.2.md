Instructions

Create a simple TDD test case
Create a new subdirectory in week sevens home directory and name it tdd-example
Create a barebone package.json file with your information (see the barebone’s package.json file example) and add it to the tdd-example directory
From the tdd-example directory install Mocha Chai (npm install mocha chai --save)
Create a new directory and name it test
Add a new JavaScript file to the test directory and name it <yourLastName>-<assignmentName>.js
Add the examples code (don’t just use copy/paste, actually go through the process of typing everything out.  Remember, repetition is the key to retention)
Run and test the unit test using the npm manager (type npm test)

Here is my GitHub repository for Exercise 7.2:

https://github.com/VisionsICStudios/web-340/tree/master/week-7/tdd-example

Also I have included a zip file of these files.
