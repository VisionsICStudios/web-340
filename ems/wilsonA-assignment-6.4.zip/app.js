/*
============================================
; Title: wilsonA-assignment-6.4.js
; Author: Professor Krasso
; Date: 22 March 2019
; Modified By: Aaron Wilson
; Description: EMS app w/ EJS (Milestone 2).
;===========================================
*/

// Header info.
const header = require('../header.js');

// Output to the console the header info.
console.log(`${header.display('Aaron', 'Wilson', 'Assignment 5.4')}\n`);

// Required modules to run NodeJS correctly w/ express.
const express = require('express');
const http = require('http');
const path = require('path');
const logger = require('morgan');
const bodyParser = require('body-parser');

// Implement express through use of this app variable.
const app = express();

// Set the proper path to point to the views folder.
app.set('views', path.resolve(__dirname, 'views'));

// Set the app view engine to point to the ejs template viewing engine.
app.set('view engine', 'ejs');

// Use the morgan logger through the express app method call.
app.use(logger('dev'));
app.set('port', process.env.PORT || 5555);



// Get request on home page.
app.get('/', (req,res) => {
	
	// Create a employee variable each holding a string.
	const employee = 'Aaron Wilson';
	
    res.render('index', {
		
        title: 'EMS | Landing Page',
		
		employee: employee
		
    });
});

// Get request on new page.
app.get('/new', (req, res) => {
	
    res.render('new',{
		
        title: 'EMS | Add New Employee'
    });
	
});

// Get request on list page.
app.get('/list', (req, res) => {
    
    Employee.find({}, (error, employees) => {
		
        if (error) throw error;

        res.render('list', {
			
            title: 'EMS | Company Employee List',
			
            employees: employees
        });
    });    
});

app.use('css' ,express.static(__dirname + 'css'));

http.createServer(app).listen(app.get('port'), () => {
	
    console.log('Application started on port ' + app.get('port'))
	
});
